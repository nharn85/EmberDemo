App = Ember.Application.create();

App.Router.map( function() {
    this.resource( 'index', { path: '/' } ); // Takes us to index
});
 
App.IndexRoute = Ember.Route.extend({
  model: function() {
    return ['red', 'yellow', 'blue'];
  }
});
