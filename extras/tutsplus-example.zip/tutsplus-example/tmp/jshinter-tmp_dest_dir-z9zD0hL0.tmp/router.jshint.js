module('JSHint - .');
test('router.js should pass jshint', function() { 
  ok(true, 'router.js should pass jshint.'); 
});
