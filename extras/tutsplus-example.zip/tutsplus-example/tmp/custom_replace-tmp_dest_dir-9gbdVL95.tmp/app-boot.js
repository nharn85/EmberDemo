/* jshint ignore:start */

define('tutsplus-example/config/environment', ['ember'], function(Ember) {
  var prefix = 'tutsplus-example';
/* jshint ignore:start */

try {
  var metaName = prefix + '/config/environment';
  var rawConfig = Ember['default'].$('meta[name="' + metaName + '"]').attr('content');
  var config = JSON.parse(unescape(rawConfig));

  return { 'default': config };
}
catch(err) {
  throw new Error('Could not read config from meta tag with name "' + metaName + '".');
}

/* jshint ignore:end */

});

if (runningTests) {
  require("tutsplus-example/tests/test-helper");
} else {
  require("tutsplus-example/app")["default"].create({"name":"tutsplus-example","version":"0.0.0.3b7ac907"});
}

/* jshint ignore:end */
