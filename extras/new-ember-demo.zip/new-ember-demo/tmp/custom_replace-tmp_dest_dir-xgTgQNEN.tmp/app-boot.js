/* jshint ignore:start */

define('new-ember-demo/config/environment', ['ember'], function(Ember) {
  var prefix = 'new-ember-demo';
/* jshint ignore:start */

try {
  var metaName = prefix + '/config/environment';
  var rawConfig = Ember['default'].$('meta[name="' + metaName + '"]').attr('content');
  var config = JSON.parse(unescape(rawConfig));

  return { 'default': config };
}
catch(err) {
  throw new Error('Could not read config from meta tag with name "' + metaName + '".');
}

/* jshint ignore:end */

});

if (runningTests) {
  require("new-ember-demo/tests/test-helper");
} else {
  require("new-ember-demo/app")["default"].create({"name":"new-ember-demo","version":"0.0.0.9314a975"});
}

/* jshint ignore:end */
