module('JSHint - helpers');
test('helpers/start-app.js should pass jshint', function() { 
  ok(true, 'helpers/start-app.js should pass jshint.'); 
});
